module Reline
  VERSION = '0.2.5'
end
