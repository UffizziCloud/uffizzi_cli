# frozen_string_literal: true
module RDoc::RI

  Store = RDoc::Store # :nodoc:

end

