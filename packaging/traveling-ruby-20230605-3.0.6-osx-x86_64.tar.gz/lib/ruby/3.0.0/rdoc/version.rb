module RDoc

  ##
  # RDoc version you are using

  VERSION = '6.3.3'

end
